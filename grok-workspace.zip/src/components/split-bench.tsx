import { useEffect, useRef, useState, type ReactNode } from "react";

type Device = "temp" | "dial";

const ROM = "28FF641E0A112233";

function f2(n: number) {
  return (Math.round(n * 100) / 100).toFixed(2);
}

function bootTemp(period: number, stream: boolean) {
  return `{"t":"boot","fw":"s3-temp","ver":"1.0.0","sensor":"ds18b20","dq":4,"tx":17,"rx":16,"period":${period},"stream":${stream ? "true" : "false"}}`;
}

function sampleLine(seq: number, ms: number, c: number, unit: string, fault: boolean) {
  if (fault) {
    return `{"t":"sample","seq":${seq},"ms":${ms},"ok":false,"sensor":"ds18b20","unit":"${unit}","n":0,"err":"no-device"}`;
  }
  const f = c * 9 / 5 + 32;
  return `{"t":"sample","seq":${seq},"ms":${ms},"ok":true,"sensor":"ds18b20","unit":"${unit}","n":1,"c":${f2(c)},"f":${f2(f)},"sensors":[{"rom":"${ROM}","c":${f2(c)},"f":${f2(f)},"ok":true}]}`;
}

function bootDial(pos: number, hid: boolean) {
  return `{"t":"boot","fw":"s3-dial","ver":"1.0.0","hidBuild":true,"hid":${hid ? "true" : "false"},"pos":${pos},"a":4,"b":5,"sw":6,"tx":17,"rx":16}`;
}

const tempPins = [
  ["3V3", "DS18B20 VDD", "3.3 V only. 5 V on DQ will damage the pin."],
  ["GND", "DS18B20 GND", "Share ground with the probe and any host."],
  ["GPIO4", "DS18B20 DQ", "Data. Put 4.7 kΩ between this pin and 3V3."],
  ["GPIO17", "Host RX", "Optional. This board transmits JSON here."],
  ["GPIO16", "Host TX", "Optional. Commands come in here."],
  ["GPIO48", "RGB flash", "Short status blink. Set kRgbEnable to 0 if the module uses this pin for flash."],
];

const dialPins = [
  ["GPIO4", "Encoder A / CLK", "Internal pull-up. Swap with B if the direction is backwards."],
  ["GPIO5", "Encoder B / DT", "Set kSwapAB or trade the two wires."],
  ["GPIO6", "Encoder switch", "Active low. Click is mute, hold is play/pause."],
  ["3V3", "Encoder +", "Powers the module pull-ups. Not 5 V."],
  ["GND", "Encoder GND", ""],
  ["GPIO17", "Host RX", "Same optional UART as the temp sketch."],
  ["GPIO16", "Host TX", "115200 8N1."],
  ["GPIO19/20", "Leave open", "Native USB. The volume keys need this port."],
];

function Card({ title, kicker, children }: { title: string; kicker: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-line bg-panel p-4">
      <p className="text-xs font-medium tracking-widest text-dim uppercase">{kicker}</p>
      <h2 className="mt-1 text-lg font-semibold text-bone">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function PinList({ rows }: { rows: string[][] }) {
  return (
    <ul className="flex flex-col gap-3">
      {rows.map((row) => (
        <li key={row[0]} className="flex gap-3">
          <span className="w-24 shrink-0 font-mono text-sm text-copper">{row[0]}</span>
          <span className="min-w-0 text-sm">
            <span className="block text-bone">{row[1]}</span>
            {row[2] ? <span className="mt-0.5 block text-mist">{row[2]}</span> : null}
          </span>
        </li>
      ))}
    </ul>
  );
}

function Btn({
  children,
  onClick,
  pressed,
}: {
  children: ReactNode;
  onClick: () => void;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "min-h-11 rounded-xl px-3 py-2 text-sm font-medium " +
        (pressed ? "bg-copper text-iron" : "border border-line bg-graphite text-bone")
      }
    >
      {children}
    </button>
  );
}

function Console({ lines }: { lines: string[] }) {
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = box.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines]);
  return (
    <div
      ref={box}
      className="h-52 overflow-auto rounded-xl border border-line bg-iron p-3 font-mono text-xs leading-relaxed text-mist"
      aria-live="polite"
    >
      {lines.map((line, i) => (
        <div key={`${i}-${line.slice(0, 24)}`} className="break-all whitespace-pre-wrap text-bone">
          {line}
        </div>
      ))}
    </div>
  );
}

function SourcePanel({ href, filename }: { href: string; filename: string }) {
  const [text, setText] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let cancel = false;
    setText(null);
    setFailed(false);
    fetch(href)
      .then((res) => {
        if (!res.ok) throw new Error("missing");
        return res.text();
      })
      .then((body) => {
        if (!cancel) setText(body);
      })
      .catch(() => {
        if (!cancel) setFailed(true);
      });
    return () => {
      cancel = true;
    };
  }, [href]);

  async function copy() {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap gap-2">
        <a
          href={href}
          download={filename}
          className="inline-flex min-h-11 items-center rounded-xl bg-copper px-4 text-sm font-semibold text-iron"
        >
          Download {filename}
        </a>
        <button
          type="button"
          onClick={copy}
          disabled={!text}
          className="min-h-11 rounded-xl border border-line bg-graphite px-4 text-sm font-medium text-bone disabled:opacity-50"
        >
          {copied ? "Copied" : "Copy sketch"}
        </button>
      </div>
      <div className="max-h-96 overflow-auto rounded-xl border border-line bg-iron p-3">
        {failed ? (
          <p className="text-sm text-mist">Sketch file did not load.</p>
        ) : text == null ? (
          <p className="text-sm text-mist">Loading sketch…</p>
        ) : (
          <pre className="font-mono text-xs leading-relaxed text-bone">{text}</pre>
        )}
      </div>
    </div>
  );
}

function TempBench() {
  const [celsius, setCelsius] = useState(23.5);
  const [unit, setUnit] = useState<"C" | "F">("C");
  const [stream, setStream] = useState(true);
  const [period, setPeriod] = useState(1000);
  const [fault, setFault] = useState(false);
  const [draft, setDraft] = useState("");
  const [lines, setLines] = useState<string[]>(() => [bootTemp(1000, true)]);
  const world = useRef({ c: 23.5, fault: false, unit: "C" as "C" | "F" });
  const seq = useRef(0);
  const t0 = useRef(0);
  world.current = { c: celsius, fault, unit };

  function push(line: string) {
    setLines((prev) => [...prev, line].slice(-40));
  }

  function emitSample() {
    seq.current += 1;
    const ms = Math.max(0, Math.round(performance.now() - t0.current));
    const w = world.current;
    push(sampleLine(seq.current, ms, w.c, w.unit, w.fault));
  }

  useEffect(() => {
    t0.current = performance.now();
    if (!stream) return;
    emitSample();
    const id = window.setInterval(emitSample, period);
    return () => window.clearInterval(id);
    // emitSample closes over push/world refs; period and stream define the cadence.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stream, period]);

  function command(raw: string) {
    const cmd = raw.trim().toUpperCase().replace(/\s+/g, " ");
    if (!cmd) return;
    if (cmd === "HELP") {
      push('{"t":"help","cmds":["ID","READ","STREAM ON","STREAM OFF","PERIOD <ms>","UNIT C","UNIT F","HELP"]}');
      return;
    }
    if (cmd === "ID") {
      push(bootTemp(period, stream));
      return;
    }
    if (cmd === "READ") {
      emitSample();
      return;
    }
    if (cmd === "STREAM ON") {
      setStream(true);
      push('{"t":"stream","on":true}');
      return;
    }
    if (cmd === "STREAM OFF") {
      setStream(false);
      push('{"t":"stream","on":false}');
      return;
    }
    if (cmd.startsWith("PERIOD ")) {
      let v = Number.parseInt(cmd.slice(7), 10);
      if (!Number.isFinite(v)) {
        push('{"t":"err","msg":"unknown-cmd"}');
        return;
      }
      if (v < 800) v = 800;
      if (v > 60000) v = 60000;
      setPeriod(v);
      push(`{"t":"period","ms":${v}}`);
      return;
    }
    if (cmd === "UNIT C" || cmd === "UNIT F") {
      const next = cmd.endsWith("F") ? "F" : "C";
      setUnit(next);
      world.current.unit = next;
      push(`{"t":"unit","unit":"${next}"}`);
      return;
    }
    push('{"t":"err","msg":"unknown-cmd"}');
  }

  const shown = unit === "C" ? celsius : (celsius * 9) / 5 + 32;

  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-2xl border border-line bg-panel p-4">
        <div className="flex items-baseline justify-between gap-3">
          <p className="text-xs font-medium tracking-widest text-dim uppercase">Bench · not the chip</p>
          <p className="font-mono text-xs text-copper">{stream ? "Streaming" : "Idle"}</p>
        </div>
        <p className="mt-6 font-mono text-5xl leading-none font-medium nums text-bone">
          {fault ? "—" : shown.toFixed(2)}
          <span className="ml-2 text-2xl text-copper">{fault ? "" : `°${unit}`}</span>
        </p>
        <p className="mt-2 text-sm text-mist">{fault ? "Bus open. The next line is no-device." : "Probe temperature"}</p>
        <label className="mt-6 block text-sm text-mist">
          Probe
          <input
            className="mt-2"
            type="range"
            min={-10}
            max={85}
            step={0.1}
            value={celsius}
            aria-label="Probe temperature in celsius"
            onChange={(e) => setCelsius(Number(e.target.value))}
          />
        </label>
        <div className="mt-1 flex justify-between font-mono text-xs text-dim">
          <span>-10</span>
          <span>85 °C</span>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Btn pressed={fault} onClick={() => setFault((v) => !v)}>
            {fault ? "Plug sensor back in" : "Unplug sensor"}
          </Btn>
        </div>
        <p className="mt-3 text-sm text-dim">
          The slider is the DS18B20. It is not a command. Drag it and the next sample follows.
        </p>
      </section>

      <Card kicker="Serial · 115200" title="What the firmware prints">
        <Console lines={lines} />
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn onClick={() => command("READ")}>READ</Btn>
          <Btn pressed={stream} onClick={() => command(stream ? "STREAM OFF" : "STREAM ON")}>
            {stream ? "STREAM OFF" : "STREAM ON"}
          </Btn>
          <Btn pressed={unit === "C"} onClick={() => command("UNIT C")}>
            UNIT C
          </Btn>
          <Btn pressed={unit === "F"} onClick={() => command("UNIT F")}>
            UNIT F
          </Btn>
          <Btn onClick={() => command("PERIOD 1000")}>1 s</Btn>
          <Btn onClick={() => command("PERIOD 2000")}>2 s</Btn>
        </div>
        <form
          className="mt-3 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            command(draft);
            setDraft("");
          }}
        >
          <input
            type="text"
            value={draft}
            aria-label="Serial command"
            placeholder="PERIOD 1000"
            onChange={(e) => setDraft(e.target.value)}
          />
          <button type="submit" className="min-h-11 shrink-0 rounded-xl bg-copper px-4 text-sm font-semibold text-iron">
            Send
          </button>
        </form>
      </Card>
    </div>
  );
}

function DialBench() {
  const [pos, setPos] = useState(0);
  const [volume, setVolume] = useState(40);
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [hid, setHid] = useState(true);
  const [draft, setDraft] = useState("");
  const [lines, setLines] = useState<string[]>(() => [bootDial(0, true)]);
  const posRef = useRef(0);
  const hidRef = useRef(true);
  const lastTurn = useRef(0);
  const hit = useRef<HTMLDivElement>(null);
  const drag = useRef<{ last: number; carry: number } | null>(null);
  const hold = useRef<number | null>(null);
  const longFired = useRef(false);

  function push(line: string) {
    setLines((prev) => [...prev, line].slice(-40));
  }

  function turn(dir: 1 | -1) {
    const now = performance.now();
    const gap = lastTurn.current === 0 ? 1000 : now - lastTurn.current;
    lastTurn.current = now;
    const repeat = gap < 40 ? 4 : gap < 90 ? 2 : 1;
    posRef.current += dir;
    setPos(posRef.current);
    const hidOn = hidRef.current;
    if (hidOn) {
      setMuted(false);
      setVolume((v) => Math.max(0, Math.min(100, v + dir * repeat)));
    }
    push(
      `{"t":"turn","dir":${dir},"pos":${posRef.current},"detents":1,"repeat":${repeat},"hid":"${hidOn ? (dir > 0 ? "vol+" : "vol-") : "off"}"}`,
    );
  }

  function click() {
    if (hidRef.current) setMuted((m) => !m);
    push(`{"t":"btn","act":"click","hid":"${hidRef.current ? "mute" : "off"}"}`);
  }

  function longPress() {
    if (hidRef.current) setPlaying((p) => !p);
    push(`{"t":"btn","act":"long","hid":"${hidRef.current ? "playpause" : "off"}"}`);
  }

  function command(raw: string) {
    const cmd = raw.trim().toUpperCase().replace(/\s+/g, " ");
    if (!cmd) return;
    if (cmd === "HELP") {
      push('{"t":"help","cmds":["ID","POS","ZERO","HID ON","HID OFF","HELP"]}');
      return;
    }
    if (cmd === "ID") {
      push(bootDial(posRef.current, hidRef.current));
      return;
    }
    if (cmd === "POS") {
      push(`{"t":"pos","pos":${posRef.current}}`);
      return;
    }
    if (cmd === "ZERO") {
      posRef.current = 0;
      setPos(0);
      push('{"t":"zero","pos":0}');
      return;
    }
    if (cmd === "HID ON" || cmd === "HID OFF") {
      const on = cmd === "HID ON";
      hidRef.current = on;
      setHid(on);
      push(`{"t":"hid","on":${on ? "true" : "false"}}`);
      return;
    }
    push('{"t":"err","msg":"unknown-cmd"}');
  }

  function angleOf(e: { clientX: number; clientY: number }) {
    const el = hit.current;
    if (!el) return 0;
    const r = el.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2);
    const dy = e.clientY - (r.top + r.height / 2);
    return (Math.atan2(dy, dx) * 180) / Math.PI;
  }

  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-2xl border border-line bg-panel p-4">
        <div className="flex items-baseline justify-between gap-3">
          <p className="text-xs font-medium tracking-widest text-dim uppercase">Bench · not the chip</p>
          <p className="font-mono text-xs text-copper">{hid ? "HID live" : "HID off"}</p>
        </div>
        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            type="button"
            className="min-h-11 min-w-11 rounded-xl border border-line bg-graphite px-3 text-lg text-bone"
            aria-label="Counterclockwise detent"
            onClick={() => turn(-1)}
          >
            −
          </button>
          <div
            ref={hit}
            className="knob-hit relative h-56 w-56"
            role="slider"
            tabIndex={0}
            aria-label="Encoder"
            aria-valuemin={-999}
            aria-valuemax={999}
            aria-valuenow={pos}
            aria-valuetext={`${pos} detents`}
            onKeyDown={(e) => {
              if (e.key === "ArrowRight" || e.key === "ArrowUp") {
                e.preventDefault();
                turn(1);
              } else if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
                e.preventDefault();
                turn(-1);
              } else if (e.key === "Enter") {
                e.preventDefault();
                click();
              }
            }}
            onPointerDown={(e) => {
              if ((e.target as HTMLElement).dataset.sw === "1") return;
              e.currentTarget.setPointerCapture(e.pointerId);
              drag.current = { last: angleOf(e), carry: 0 };
            }}
            onPointerMove={(e) => {
              if (!drag.current) return;
              let delta = angleOf(e) - drag.current.last;
              if (delta > 180) delta -= 360;
              if (delta < -180) delta += 360;
              drag.current.last = angleOf(e);
              drag.current.carry += delta;
              const step = 15;
              while (drag.current.carry >= step) {
                drag.current.carry -= step;
                turn(1);
              }
              while (drag.current.carry <= -step) {
                drag.current.carry += step;
                turn(-1);
              }
            }}
            onPointerUp={() => {
              drag.current = null;
            }}
            onPointerCancel={() => {
              drag.current = null;
            }}
          >
            <div
              className="knob-disc pointer-events-none absolute inset-0 rounded-full border border-line bg-graphite transition-transform duration-75"
              style={{ transform: `rotate(${pos * 15}deg)` }}
            >
              <span className="absolute top-3 left-1/2 h-8 w-1 -translate-x-1/2 rounded-full bg-copper" />
            </div>
            <button
              type="button"
              data-sw="1"
              aria-label="Encoder push. Click for mute, hold for play pause"
              className="absolute top-1/2 left-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-iron text-xs font-medium text-bone"
              onPointerDown={(e) => {
                e.stopPropagation();
                e.currentTarget.setPointerCapture(e.pointerId);
                longFired.current = false;
                hold.current = window.setTimeout(() => {
                  longFired.current = true;
                  longPress();
                }, 700);
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                if (hold.current != null) window.clearTimeout(hold.current);
                hold.current = null;
                if (!longFired.current) click();
              }}
              onPointerCancel={() => {
                if (hold.current != null) window.clearTimeout(hold.current);
                hold.current = null;
              }}
            >
              Push
            </button>
          </div>
          <button
            type="button"
            className="min-h-11 min-w-11 rounded-xl border border-line bg-graphite px-3 text-lg text-bone"
            aria-label="Clockwise detent"
            onClick={() => turn(1)}
          >
            +
          </button>
        </div>
        <p className="mt-4 text-center font-mono text-sm nums text-mist">
          Position {pos} · drag, or use + and −
        </p>
        <div className="mt-5">
          <div className="flex items-baseline justify-between text-sm">
            <span className="text-mist">PC volume</span>
            <span className="font-mono nums text-bone">{muted ? "Muted" : volume}</span>
          </div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-iron">
            <div
              className={"h-full rounded-full " + (muted || !hid ? "bg-line" : "bg-copper")}
              style={{ width: `${volume}%` }}
            />
          </div>
          <p className="mt-2 text-sm text-dim">
            {playing ? "Playing" : "Paused"}
            {hid ? "" : " · volume keys are not being sent"}
            . This bar is the computer, not a JSON field.
          </p>
        </div>
      </section>

      <Card kicker="Serial · 115200" title="What the firmware prints">
        <Console lines={lines} />
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn onClick={() => command("ZERO")}>ZERO</Btn>
          <Btn pressed={hid} onClick={() => command(hid ? "HID OFF" : "HID ON")}>
            {hid ? "HID OFF" : "HID ON"}
          </Btn>
          <Btn onClick={() => command("POS")}>POS</Btn>
        </div>
        <form
          className="mt-3 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            command(draft);
            setDraft("");
          }}
        >
          <input
            type="text"
            value={draft}
            aria-label="Serial command"
            placeholder="HID OFF"
            onChange={(e) => setDraft(e.target.value)}
          />
          <button type="submit" className="min-h-11 shrink-0 rounded-xl bg-copper px-4 text-sm font-semibold text-iron">
            Send
          </button>
        </form>
      </Card>
    </div>
  );
}

export function SplitBench() {
  const [device, setDevice] = useState<Device>("temp");
  const temp = device === "temp";

  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-4 px-4 py-6">
      <header>
        <p className="font-mono text-xs tracking-widest text-copper uppercase">ESP32-S3</p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight text-bone">Split</h1>
        <p className="mt-2 max-w-xl text-base text-mist">
          Two sketches, not one. Flash a board as a temperature node, or flash another as a rotary dial.
          Both answer on USB serial and on the same optional UART.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-2" role="tablist" aria-label="Firmware">
        <button
          type="button"
          role="tab"
          aria-selected={temp}
          className={
            "min-h-11 rounded-xl px-3 text-sm font-semibold " +
            (temp ? "bg-copper text-iron" : "border border-line bg-panel text-bone")
          }
          onClick={() => setDevice("temp")}
        >
          Temp node
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={!temp}
          className={
            "min-h-11 rounded-xl px-3 text-sm font-semibold " +
            (!temp ? "bg-copper text-iron" : "border border-line bg-panel text-bone")
          }
          onClick={() => setDevice("dial")}
        >
          Rotary dial
        </button>
      </div>

      <a
        href="/firmware/s3-split.zip"
        download
        className="inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-graphite px-4 text-sm font-medium text-bone"
      >
        Download both sketches
      </a>

      {temp ? <TempBench /> : <DialBench />}

      <Card kicker="Wire" title={temp ? "DS18B20 on GPIO4" : "Encoder on GPIO4, 5, and 6"}>
        <PinList rows={temp ? tempPins : dialPins} />
      </Card>

      <Card kicker="Flash" title="Arduino IDE 2 · ESP32 core 3">
        <ol className="list-decimal space-y-2 pl-5 text-sm text-bone">
          <li>Boards Manager: install esp32 by Espressif, version 3.0 or newer.</li>
          <li>Board: ESP32S3 Dev Module. Set flash size and PSRAM to match the module in your hand.</li>
          {temp ? (
            <li>USB CDC On Boot: Enabled. USB Mode: Hardware CDC and JTAG, or USB-OTG. Either port prints JSON.</li>
          ) : (
            <li>
              USB CDC On Boot: Enabled. USB Mode: USB-OTG (TinyUSB). Plug into the native USB socket for volume
              keys. Hardware-CDC builds still print JSON, with HID compiled out.
            </li>
          )}
          <li>Open the downloaded .ino from its own folder. The folder name has to match the file.</li>
          <li>No libraries. Upload. Serial monitor at 115200.</li>
          {temp ? null : (
            <li>If the port vanishes on the next upload, hold BOOT, tap RESET, release BOOT, then upload.</li>
          )}
        </ol>
        <p className="mt-4 text-sm text-mist">
          {temp
            ? "Change kSensorMode to 0 to print the chip die temperature with nothing wired. That number is the silicon, not the room."
            : "ESP32 and ESP32-C3 will not enumerate as this volume knob. The S3 native USB controller is the one that does."}
        </p>
        <div className="mt-4">
          <a
            href={temp ? "/firmware/s3-temp/s3-temp.ino" : "/firmware/s3-dial/s3-dial.ino"}
            download
            className="inline-flex min-h-11 items-center rounded-xl bg-copper px-4 text-sm font-semibold text-iron"
          >
            {temp ? "Download s3-temp.ino" : "Download s3-dial.ino"}
          </a>
        </div>
      </Card>

      <Card kicker="Protocol" title="One JSON object per line">
        {temp ? (
          <div className="flex flex-col gap-3 text-sm text-mist">
            <p>Samples carry Celsius and Fahrenheit either way. `unit` is only which one you asked to prefer. `c` on the top line is the first healthy sensor. Up to four DS18B20s share the bus; each shows up in `sensors`.</p>
            <pre className="overflow-auto rounded-xl border border-line bg-iron p-3 font-mono text-xs leading-relaxed text-bone">{`{"t":"sample","seq":1,"ms":1000,"ok":true,"sensor":"ds18b20","unit":"C","n":1,"c":23.50,"f":74.30,"sensors":[{"rom":"${ROM}","c":23.50,"f":74.30,"ok":true}]}`}</pre>
            <p>Commands: READ, STREAM ON, STREAM OFF, PERIOD milliseconds (800 to 60000), UNIT C, UNIT F, ID, HELP.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3 text-sm text-mist">
            <p>
              A detent is one JSON line. `repeat` is 1, 2, or 4: how many volume keys that detent becomes when
              the knob is moving fast. `pos` is the absolute count since boot or ZERO. Click sends mute. A 700 ms
              hold sends play/pause and does not also click.
            </p>
            <pre className="overflow-auto rounded-xl border border-line bg-iron p-3 font-mono text-xs leading-relaxed text-bone">{`{"t":"turn","dir":1,"pos":3,"detents":1,"repeat":1,"hid":"vol+"}
{"t":"btn","act":"click","hid":"mute"}`}</pre>
            <p>Commands: POS, ZERO, HID ON, HID OFF, ID, HELP. HID OFF keeps the JSON and stops the volume keys.</p>
            <p>Fast clicks that double up: set kStepsPerDetent to 2. Backwards: set kSwapAB to true.</p>
          </div>
        )}
      </Card>

      <Card kicker="Sketch" title={temp ? "s3-temp.ino" : "s3-dial.ino"}>
        <SourcePanel
          href={temp ? "/firmware/s3-temp/s3-temp.ino" : "/firmware/s3-dial/s3-dial.ino"}
          filename={temp ? "s3-temp.ino" : "s3-dial.ino"}
        />
      </Card>
    </main>
  );
}
