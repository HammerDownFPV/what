import { createFileRoute } from "@tanstack/react-router";
import { SplitBench } from "@/components/split-bench";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SplitBench />;
}
