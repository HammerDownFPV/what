//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BjP2BF1P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BUt6pgdc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BUt6pgdc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DDoQP1qF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
