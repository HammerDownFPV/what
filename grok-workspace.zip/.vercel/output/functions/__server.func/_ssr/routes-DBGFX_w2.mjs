import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DBGFX_w2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROM = "28FF641E0A112233";
function f2(n) {
	return (Math.round(n * 100) / 100).toFixed(2);
}
function bootTemp(period, stream) {
	return `{"t":"boot","fw":"s3-temp","ver":"1.0.0","sensor":"ds18b20","dq":4,"tx":17,"rx":16,"period":${period},"stream":${stream ? "true" : "false"}}`;
}
function sampleLine(seq, ms, c, unit, fault) {
	if (fault) return `{"t":"sample","seq":${seq},"ms":${ms},"ok":false,"sensor":"ds18b20","unit":"${unit}","n":0,"err":"no-device"}`;
	const f = c * 9 / 5 + 32;
	return `{"t":"sample","seq":${seq},"ms":${ms},"ok":true,"sensor":"ds18b20","unit":"${unit}","n":1,"c":${f2(c)},"f":${f2(f)},"sensors":[{"rom":"${ROM}","c":${f2(c)},"f":${f2(f)},"ok":true}]}`;
}
function bootDial(pos, hid) {
	return `{"t":"boot","fw":"s3-dial","ver":"1.0.0","hidBuild":true,"hid":${hid ? "true" : "false"},"pos":${pos},"a":4,"b":5,"sw":6,"tx":17,"rx":16}`;
}
var tempPins = [
	[
		"3V3",
		"DS18B20 VDD",
		"3.3 V only. 5 V on DQ will damage the pin."
	],
	[
		"GND",
		"DS18B20 GND",
		"Share ground with the probe and any host."
	],
	[
		"GPIO4",
		"DS18B20 DQ",
		"Data. Put 4.7 kΩ between this pin and 3V3."
	],
	[
		"GPIO17",
		"Host RX",
		"Optional. This board transmits JSON here."
	],
	[
		"GPIO16",
		"Host TX",
		"Optional. Commands come in here."
	],
	[
		"GPIO48",
		"RGB flash",
		"Short status blink. Set kRgbEnable to 0 if the module uses this pin for flash."
	]
];
var dialPins = [
	[
		"GPIO4",
		"Encoder A / CLK",
		"Internal pull-up. Swap with B if the direction is backwards."
	],
	[
		"GPIO5",
		"Encoder B / DT",
		"Set kSwapAB or trade the two wires."
	],
	[
		"GPIO6",
		"Encoder switch",
		"Active low. Click is mute, hold is play/pause."
	],
	[
		"3V3",
		"Encoder +",
		"Powers the module pull-ups. Not 5 V."
	],
	[
		"GND",
		"Encoder GND",
		""
	],
	[
		"GPIO17",
		"Host RX",
		"Same optional UART as the temp sketch."
	],
	[
		"GPIO16",
		"Host TX",
		"115200 8N1."
	],
	[
		"GPIO19/20",
		"Leave open",
		"Native USB. The volume keys need this port."
	]
];
function Card({ title, kicker, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-dim uppercase",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-lg font-semibold text-bone",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})
		]
	});
}
function PinList({ rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-3",
		children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-24 shrink-0 font-mono text-sm text-copper",
				children: row[0]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-bone",
					children: row[1]
				}), row[2] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-mist",
					children: row[2]
				}) : null]
			})]
		}, row[0]))
	});
}
function Btn({ children, onClick, pressed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "min-h-11 rounded-xl px-3 py-2 text-sm font-medium " + (pressed ? "bg-copper text-iron" : "border border-line bg-graphite text-bone"),
		children
	});
}
function Console({ lines }) {
	const box = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = box.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [lines]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: box,
		className: "h-52 overflow-auto rounded-xl border border-line bg-iron p-3 font-mono text-xs leading-relaxed text-mist",
		"aria-live": "polite",
		children: lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "break-all whitespace-pre-wrap text-bone",
			children: line
		}, `${i}-${line.slice(0, 24)}`))
	});
}
function SourcePanel({ href, filename }) {
	const [text, setText] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		setText(null);
		setFailed(false);
		fetch(href).then((res) => {
			if (!res.ok) throw new Error("missing");
			return res.text();
		}).then((body) => {
			if (!cancel) setText(body);
		}).catch(() => {
			if (!cancel) setFailed(true);
		});
		return () => {
			cancel = true;
		};
	}, [href]);
	async function copy() {
		if (!text) return;
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1400);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex flex-wrap gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href,
			download: filename,
			className: "inline-flex min-h-11 items-center rounded-xl bg-copper px-4 text-sm font-semibold text-iron",
			children: ["Download ", filename]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: copy,
			disabled: !text,
			className: "min-h-11 rounded-xl border border-line bg-graphite px-4 text-sm font-medium text-bone disabled:opacity-50",
			children: copied ? "Copied" : "Copy sketch"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "max-h-96 overflow-auto rounded-xl border border-line bg-iron p-3",
		children: failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-mist",
			children: "Sketch file did not load."
		}) : text == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-mist",
			children: "Loading sketch…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "font-mono text-xs leading-relaxed text-bone",
			children: text
		})
	})] });
}
function TempBench() {
	const [celsius, setCelsius] = (0, import_react.useState)(23.5);
	const [unit, setUnit] = (0, import_react.useState)("C");
	const [stream, setStream] = (0, import_react.useState)(true);
	const [period, setPeriod] = (0, import_react.useState)(1e3);
	const [fault, setFault] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)(() => [bootTemp(1e3, true)]);
	const world = (0, import_react.useRef)({
		c: 23.5,
		fault: false,
		unit: "C"
	});
	const seq = (0, import_react.useRef)(0);
	const t0 = (0, import_react.useRef)(0);
	world.current = {
		c: celsius,
		fault,
		unit
	};
	function push(line) {
		setLines((prev) => [...prev, line].slice(-40));
	}
	function emitSample() {
		seq.current += 1;
		const ms = Math.max(0, Math.round(performance.now() - t0.current));
		const w = world.current;
		push(sampleLine(seq.current, ms, w.c, w.unit, w.fault));
	}
	(0, import_react.useEffect)(() => {
		t0.current = performance.now();
		if (!stream) return;
		emitSample();
		const id = window.setInterval(emitSample, period);
		return () => window.clearInterval(id);
	}, [stream, period]);
	function command(raw) {
		const cmd = raw.trim().toUpperCase().replace(/\s+/g, " ");
		if (!cmd) return;
		if (cmd === "HELP") {
			push("{\"t\":\"help\",\"cmds\":[\"ID\",\"READ\",\"STREAM ON\",\"STREAM OFF\",\"PERIOD <ms>\",\"UNIT C\",\"UNIT F\",\"HELP\"]}");
			return;
		}
		if (cmd === "ID") {
			push(bootTemp(period, stream));
			return;
		}
		if (cmd === "READ") {
			emitSample();
			return;
		}
		if (cmd === "STREAM ON") {
			setStream(true);
			push("{\"t\":\"stream\",\"on\":true}");
			return;
		}
		if (cmd === "STREAM OFF") {
			setStream(false);
			push("{\"t\":\"stream\",\"on\":false}");
			return;
		}
		if (cmd.startsWith("PERIOD ")) {
			let v = Number.parseInt(cmd.slice(7), 10);
			if (!Number.isFinite(v)) {
				push("{\"t\":\"err\",\"msg\":\"unknown-cmd\"}");
				return;
			}
			if (v < 800) v = 800;
			if (v > 6e4) v = 6e4;
			setPeriod(v);
			push(`{"t":"period","ms":${v}}`);
			return;
		}
		if (cmd === "UNIT C" || cmd === "UNIT F") {
			const next = cmd.endsWith("F") ? "F" : "C";
			setUnit(next);
			world.current.unit = next;
			push(`{"t":"unit","unit":"${next}"}`);
			return;
		}
		push("{\"t\":\"err\",\"msg\":\"unknown-cmd\"}");
	}
	const shown = unit === "C" ? celsius : celsius * 9 / 5 + 32;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border border-line bg-panel p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-dim uppercase",
						children: "Bench · not the chip"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-copper",
						children: stream ? "Streaming" : "Idle"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 font-mono text-5xl leading-none font-medium nums text-bone",
					children: [fault ? "—" : shown.toFixed(2), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-2xl text-copper",
						children: fault ? "" : `°${unit}`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-mist",
					children: fault ? "Bus open. The next line is no-device." : "Probe temperature"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-6 block text-sm text-mist",
					children: ["Probe", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-2",
						type: "range",
						min: -10,
						max: 85,
						step: .1,
						value: celsius,
						"aria-label": "Probe temperature in celsius",
						onChange: (e) => setCelsius(Number(e.target.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex justify-between font-mono text-xs text-dim",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "85 °C" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						pressed: fault,
						onClick: () => setFault((v) => !v),
						children: fault ? "Plug sensor back in" : "Unplug sensor"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-dim",
					children: "The slider is the DS18B20. It is not a command. Drag it and the next sample follows."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			kicker: "Serial · 115200",
			title: "What the firmware prints",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Console, { lines }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => command("READ"),
							children: "READ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							pressed: stream,
							onClick: () => command(stream ? "STREAM OFF" : "STREAM ON"),
							children: stream ? "STREAM OFF" : "STREAM ON"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							pressed: unit === "C",
							onClick: () => command("UNIT C"),
							children: "UNIT C"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							pressed: unit === "F",
							onClick: () => command("UNIT F"),
							children: "UNIT F"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => command("PERIOD 1000"),
							children: "1 s"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => command("PERIOD 2000"),
							children: "2 s"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						command(draft);
						setDraft("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: draft,
						"aria-label": "Serial command",
						placeholder: "PERIOD 1000",
						onChange: (e) => setDraft(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 shrink-0 rounded-xl bg-copper px-4 text-sm font-semibold text-iron",
						children: "Send"
					})]
				})
			]
		})]
	});
}
function DialBench() {
	const [pos, setPos] = (0, import_react.useState)(0);
	const [volume, setVolume] = (0, import_react.useState)(40);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [playing, setPlaying] = (0, import_react.useState)(true);
	const [hid, setHid] = (0, import_react.useState)(true);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)(() => [bootDial(0, true)]);
	const posRef = (0, import_react.useRef)(0);
	const hidRef = (0, import_react.useRef)(true);
	const lastTurn = (0, import_react.useRef)(0);
	const hit = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(null);
	const hold = (0, import_react.useRef)(null);
	const longFired = (0, import_react.useRef)(false);
	function push(line) {
		setLines((prev) => [...prev, line].slice(-40));
	}
	function turn(dir) {
		const now = performance.now();
		const gap = lastTurn.current === 0 ? 1e3 : now - lastTurn.current;
		lastTurn.current = now;
		const repeat = gap < 40 ? 4 : gap < 90 ? 2 : 1;
		posRef.current += dir;
		setPos(posRef.current);
		const hidOn = hidRef.current;
		if (hidOn) {
			setMuted(false);
			setVolume((v) => Math.max(0, Math.min(100, v + dir * repeat)));
		}
		push(`{"t":"turn","dir":${dir},"pos":${posRef.current},"detents":1,"repeat":${repeat},"hid":"${hidOn ? dir > 0 ? "vol+" : "vol-" : "off"}"}`);
	}
	function click() {
		if (hidRef.current) setMuted((m) => !m);
		push(`{"t":"btn","act":"click","hid":"${hidRef.current ? "mute" : "off"}"}`);
	}
	function longPress() {
		if (hidRef.current) setPlaying((p) => !p);
		push(`{"t":"btn","act":"long","hid":"${hidRef.current ? "playpause" : "off"}"}`);
	}
	function command(raw) {
		const cmd = raw.trim().toUpperCase().replace(/\s+/g, " ");
		if (!cmd) return;
		if (cmd === "HELP") {
			push("{\"t\":\"help\",\"cmds\":[\"ID\",\"POS\",\"ZERO\",\"HID ON\",\"HID OFF\",\"HELP\"]}");
			return;
		}
		if (cmd === "ID") {
			push(bootDial(posRef.current, hidRef.current));
			return;
		}
		if (cmd === "POS") {
			push(`{"t":"pos","pos":${posRef.current}}`);
			return;
		}
		if (cmd === "ZERO") {
			posRef.current = 0;
			setPos(0);
			push("{\"t\":\"zero\",\"pos\":0}");
			return;
		}
		if (cmd === "HID ON" || cmd === "HID OFF") {
			const on = cmd === "HID ON";
			hidRef.current = on;
			setHid(on);
			push(`{"t":"hid","on":${on ? "true" : "false"}}`);
			return;
		}
		push("{\"t\":\"err\",\"msg\":\"unknown-cmd\"}");
	}
	function angleOf(e) {
		const el = hit.current;
		if (!el) return 0;
		const r = el.getBoundingClientRect();
		const dx = e.clientX - (r.left + r.width / 2);
		const dy = e.clientY - (r.top + r.height / 2);
		return Math.atan2(dy, dx) * 180 / Math.PI;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border border-line bg-panel p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-dim uppercase",
						children: "Bench · not the chip"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-copper",
						children: hid ? "HID live" : "HID off"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex items-center justify-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 min-w-11 rounded-xl border border-line bg-graphite px-3 text-lg text-bone",
							"aria-label": "Counterclockwise detent",
							onClick: () => turn(-1),
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: hit,
							className: "knob-hit relative h-56 w-56",
							role: "slider",
							tabIndex: 0,
							"aria-label": "Encoder",
							"aria-valuemin": -999,
							"aria-valuemax": 999,
							"aria-valuenow": pos,
							"aria-valuetext": `${pos} detents`,
							onKeyDown: (e) => {
								if (e.key === "ArrowRight" || e.key === "ArrowUp") {
									e.preventDefault();
									turn(1);
								} else if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
									e.preventDefault();
									turn(-1);
								} else if (e.key === "Enter") {
									e.preventDefault();
									click();
								}
							},
							onPointerDown: (e) => {
								if (e.target.dataset.sw === "1") return;
								e.currentTarget.setPointerCapture(e.pointerId);
								drag.current = {
									last: angleOf(e),
									carry: 0
								};
							},
							onPointerMove: (e) => {
								if (!drag.current) return;
								let delta = angleOf(e) - drag.current.last;
								if (delta > 180) delta -= 360;
								if (delta < -180) delta += 360;
								drag.current.last = angleOf(e);
								drag.current.carry += delta;
								const step = 15;
								while (drag.current.carry >= step) {
									drag.current.carry -= step;
									turn(1);
								}
								while (drag.current.carry <= -15) {
									drag.current.carry += step;
									turn(-1);
								}
							},
							onPointerUp: () => {
								drag.current = null;
							},
							onPointerCancel: () => {
								drag.current = null;
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "knob-disc pointer-events-none absolute inset-0 rounded-full border border-line bg-graphite transition-transform duration-75",
								style: { transform: `rotate(${pos * 15}deg)` },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-3 left-1/2 h-8 w-1 -translate-x-1/2 rounded-full bg-copper" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-sw": "1",
								"aria-label": "Encoder push. Click for mute, hold for play pause",
								className: "absolute top-1/2 left-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-iron text-xs font-medium text-bone",
								onPointerDown: (e) => {
									e.stopPropagation();
									e.currentTarget.setPointerCapture(e.pointerId);
									longFired.current = false;
									hold.current = window.setTimeout(() => {
										longFired.current = true;
										longPress();
									}, 700);
								},
								onPointerUp: (e) => {
									e.stopPropagation();
									if (hold.current != null) window.clearTimeout(hold.current);
									hold.current = null;
									if (!longFired.current) click();
								},
								onPointerCancel: () => {
									if (hold.current != null) window.clearTimeout(hold.current);
									hold.current = null;
								},
								children: "Push"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 min-w-11 rounded-xl border border-line bg-graphite px-3 text-lg text-bone",
							"aria-label": "Clockwise detent",
							onClick: () => turn(1),
							children: "+"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-center font-mono text-sm nums text-mist",
					children: [
						"Position ",
						pos,
						" · drag, or use + and −"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mist",
								children: "PC volume"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono nums text-bone",
								children: muted ? "Muted" : volume
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-2 overflow-hidden rounded-full bg-iron",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full " + (muted || !hid ? "bg-line" : "bg-copper"),
								style: { width: `${volume}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-dim",
							children: [
								playing ? "Playing" : "Paused",
								hid ? "" : " · volume keys are not being sent",
								". This bar is the computer, not a JSON field."
							]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			kicker: "Serial · 115200",
			title: "What the firmware prints",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Console, { lines }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => command("ZERO"),
							children: "ZERO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							pressed: hid,
							onClick: () => command(hid ? "HID OFF" : "HID ON"),
							children: hid ? "HID OFF" : "HID ON"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => command("POS"),
							children: "POS"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						command(draft);
						setDraft("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: draft,
						"aria-label": "Serial command",
						placeholder: "HID OFF",
						onChange: (e) => setDraft(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 shrink-0 rounded-xl bg-copper px-4 text-sm font-semibold text-iron",
						children: "Send"
					})]
				})
			]
		})]
	});
}
function SplitBench() {
	const [device, setDevice] = (0, import_react.useState)("temp");
	const temp = device === "temp";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex max-w-3xl flex-col gap-4 px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-widest text-copper uppercase",
					children: "ESP32-S3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-4xl font-semibold tracking-tight text-bone",
					children: "Split"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-base text-mist",
					children: "Two sketches, not one. Flash a board as a temperature node, or flash another as a rotary dial. Both answer on USB serial and on the same optional UART."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				role: "tablist",
				"aria-label": "Firmware",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": temp,
					className: "min-h-11 rounded-xl px-3 text-sm font-semibold " + (temp ? "bg-copper text-iron" : "border border-line bg-panel text-bone"),
					onClick: () => setDevice("temp"),
					children: "Temp node"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": !temp,
					className: "min-h-11 rounded-xl px-3 text-sm font-semibold " + (!temp ? "bg-copper text-iron" : "border border-line bg-panel text-bone"),
					onClick: () => setDevice("dial"),
					children: "Rotary dial"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/firmware/s3-split.zip",
				download: true,
				className: "inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-graphite px-4 text-sm font-medium text-bone",
				children: "Download both sketches"
			}),
			temp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TempBench, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialBench, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				kicker: "Wire",
				title: temp ? "DS18B20 on GPIO4" : "Encoder on GPIO4, 5, and 6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinList, { rows: temp ? tempPins : dialPins })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				kicker: "Flash",
				title: "Arduino IDE 2 · ESP32 core 3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "list-decimal space-y-2 pl-5 text-sm text-bone",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Boards Manager: install esp32 by Espressif, version 3.0 or newer." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Board: ESP32S3 Dev Module. Set flash size and PSRAM to match the module in your hand." }),
							temp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "USB CDC On Boot: Enabled. USB Mode: Hardware CDC and JTAG, or USB-OTG. Either port prints JSON." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "USB CDC On Boot: Enabled. USB Mode: USB-OTG (TinyUSB). Plug into the native USB socket for volume keys. Hardware-CDC builds still print JSON, with HID compiled out." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open the downloaded .ino from its own folder. The folder name has to match the file." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No libraries. Upload. Serial monitor at 115200." }),
							temp ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If the port vanishes on the next upload, hold BOOT, tap RESET, release BOOT, then upload." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-mist",
						children: temp ? "Change kSensorMode to 0 to print the chip die temperature with nothing wired. That number is the silicon, not the room." : "ESP32 and ESP32-C3 will not enumerate as this volume knob. The S3 native USB controller is the one that does."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: temp ? "/firmware/s3-temp/s3-temp.ino" : "/firmware/s3-dial/s3-dial.ino",
							download: true,
							className: "inline-flex min-h-11 items-center rounded-xl bg-copper px-4 text-sm font-semibold text-iron",
							children: temp ? "Download s3-temp.ino" : "Download s3-dial.ino"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				kicker: "Protocol",
				title: "One JSON object per line",
				children: temp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 text-sm text-mist",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Samples carry Celsius and Fahrenheit either way. `unit` is only which one you asked to prefer. `c` on the top line is the first healthy sensor. Up to four DS18B20s share the bus; each shows up in `sensors`." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "overflow-auto rounded-xl border border-line bg-iron p-3 font-mono text-xs leading-relaxed text-bone",
							children: `{"t":"sample","seq":1,"ms":1000,"ok":true,"sensor":"ds18b20","unit":"C","n":1,"c":23.50,"f":74.30,"sensors":[{"rom":"${ROM}","c":23.50,"f":74.30,"ok":true}]}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Commands: READ, STREAM ON, STREAM OFF, PERIOD milliseconds (800 to 60000), UNIT C, UNIT F, ID, HELP." })
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 text-sm text-mist",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A detent is one JSON line. `repeat` is 1, 2, or 4: how many volume keys that detent becomes when the knob is moving fast. `pos` is the absolute count since boot or ZERO. Click sends mute. A 700 ms hold sends play/pause and does not also click." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "overflow-auto rounded-xl border border-line bg-iron p-3 font-mono text-xs leading-relaxed text-bone",
							children: `{"t":"turn","dir":1,"pos":3,"detents":1,"repeat":1,"hid":"vol+"}
{"t":"btn","act":"click","hid":"mute"}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Commands: POS, ZERO, HID ON, HID OFF, ID, HELP. HID OFF keeps the JSON and stops the volume keys." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Fast clicks that double up: set kStepsPerDetent to 2. Backwards: set kSwapAB to true." })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				kicker: "Sketch",
				title: temp ? "s3-temp.ino" : "s3-dial.ino",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcePanel, {
					href: temp ? "/firmware/s3-temp/s3-temp.ino" : "/firmware/s3-dial/s3-dial.ino",
					filename: temp ? "s3-temp.ino" : "s3-dial.ino"
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitBench, {});
}
//#endregion
export { Home as component };
