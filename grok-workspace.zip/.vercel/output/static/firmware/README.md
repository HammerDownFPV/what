# Split S3

Two separate sketches for an ESP32-S3. Flash one board as a temperature node, or flash one as a rotary dial. They are not a combined firmware.

Both speak newline JSON at 115200 and can drive the same optional host UART: GPIO17 TX, GPIO16 RX.

- `s3-temp` — DS18B20 probe
- `s3-dial` — encoder, USB volume knob
