// Split S3 — rotary encoder dial
// Board: ESP32-S3 only. Core: Arduino-ESP32 3.0 or newer. No libraries.
//
// The chip becomes the dial. A mechanical encoder (EC11 / KY-040) is read
// on GPIO4/5/6. Each detent is reported as JSON, and — when USB mode is
// OTG — also as a USB Consumer Control volume key. Click is mute.
// Hold is play/pause.
//
// Arduino IDE board settings for the volume keys:
//   USB CDC On Boot : Enabled
//   USB Mode        : USB-OTG (TinyUSB)
// Plug into the native USB connector (GPIO19/20), not the UART bridge.
// If those menus are wrong, the encoder still reports JSON; HID stays off.
//
// Wire at 3.3 V only:
//   Encoder A / CLK -> GPIO4
//   Encoder B / DT  -> GPIO5
//   Encoder push    -> GPIO6
//   Encoder +       -> 3V3
//   Encoder GND     -> GND
//
// Optional host UART, 115200 8N1 (same pins as the temp firmware):
//   GPIO17 TX -> host RX
//   GPIO16 RX -> host TX
//   GND       -> host GND
//
// If clockwise and counterclockwise are backwards, set kSwapAB to true.
// If one click produces two events, set kStepsPerDetent to 2.

static const int kPinA = 4;
static const int kPinB = 5;
static const int kPinSw = 6;
static const int kPinHostRx = 16;
static const int kPinHostTx = 17;
static const int kPinRgb = 48;
static const bool kRgbEnable = true;
static const bool kSwapAB = false;
static const int kStepsPerDetent = 4;
static const char *kVersion = "1.0.0";

#include <Arduino.h>
#include "driver/gpio.h"
#include "esp32-hal-rgb-led.h"

#ifndef ARDUINO_USB_MODE
#define DIAL_HID 0
#elif ARDUINO_USB_MODE == 1
#define DIAL_HID 0
#else
#define DIAL_HID 1
#include "USB.h"
#include "USBHIDConsumerControl.h"
USBHIDConsumerControl ConsumerControl;
#endif

static HardwareSerial HostSerial(1);

static DRAM_ATTR int8_t kQuad[16] = {
    0, +1, -1, 0,
   -1,  0,  0, +1,
   +1,  0,  0, -1,
    0, -1, +1, 0
};
static DRAM_ATTR volatile int32_t gQuarter = 0;
static DRAM_ATTR volatile uint8_t gPrevAB = 0;
static DRAM_ATTR uint8_t gPinA = 4;
static DRAM_ATTR uint8_t gPinB = 5;
static DRAM_ATTR portMUX_TYPE gMux = portMUX_INITIALIZER_UNLOCKED;

static int32_t gPos = 0;
static bool gHidLive = true;
static bool gRgbLit = false;
static uint32_t gRgbOffAt = 0;
static uint32_t gLastDetentMs = 0;

static bool gBtnStable = true;
static bool gBtnLast = true;
static uint32_t gBtnChangeMs = 0;
static bool gBtnDown = false;
static uint32_t gBtnDownMs = 0;
static bool gLongSent = false;

struct Line {
  char d[256];
  size_t n;
  void reset() {
    n = 0;
    d[0] = 0;
  }
  void raw(const char *s) {
    while (*s && n + 1 < sizeof(d)) d[n++] = *s++;
    d[n] = 0;
  }
  void ch(char c) {
    if (n + 1 < sizeof(d)) {
      d[n++] = c;
      d[n] = 0;
    }
  }
  void i32(int32_t v) {
    char tmp[16];
    snprintf(tmp, sizeof(tmp), "%ld", (long)v);
    raw(tmp);
  }
  void u32(uint32_t v) {
    char tmp[16];
    snprintf(tmp, sizeof(tmp), "%lu", (unsigned long)v);
    raw(tmp);
  }
};

static void emitLine(const char *s) {
  Serial.println(s);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial0.println(s);
#endif
  HostSerial.println(s);
}

static void rgb(uint8_t r, uint8_t g, uint8_t b) {
  if (!kRgbEnable) return;
  neopixelWrite((uint8_t)kPinRgb, r, g, b);
  gRgbLit = (r | g | b) != 0;
  gRgbOffAt = millis() + 30;
}

static void serviceRgb() {
  if (gRgbLit && (int32_t)(millis() - gRgbOffAt) >= 0) {
    neopixelWrite((uint8_t)kPinRgb, 0, 0, 0);
    gRgbLit = false;
  }
}

static void IRAM_ATTR onEncoder() {
  uint8_t a = (uint8_t)gpio_get_level((gpio_num_t)gPinA);
  uint8_t b = (uint8_t)gpio_get_level((gpio_num_t)gPinB);
  uint8_t curr = (uint8_t)((a << 1) | b);
  portENTER_CRITICAL_ISR(&gMux);
  uint8_t idx = (uint8_t)((gPrevAB << 2) | curr);
  gPrevAB = curr;
  gQuarter += kQuad[idx];
  portEXIT_CRITICAL_ISR(&gMux);
}

static int32_t takeDetents() {
  portENTER_CRITICAL(&gMux);
  int32_t q = gQuarter;
  int32_t det = q / kStepsPerDetent;
  gQuarter -= det * kStepsPerDetent;
  portEXIT_CRITICAL(&gMux);
  if (det > 6) det = 6;
  if (det < -6) det = -6;
  return det;
}

static int accelRepeat(uint32_t now) {
  uint32_t gap = gLastDetentMs == 0 ? 1000u : (now - gLastDetentMs);
  gLastDetentMs = now;
  if (gap < 40) return 4;
  if (gap < 90) return 2;
  return 1;
}

#if DIAL_HID
static void hidTap(uint16_t usage, int repeat) {
  if (!gHidLive) return;
  if (repeat < 1) repeat = 1;
  if (repeat > 8) repeat = 8;
  for (int i = 0; i < repeat; i++) {
    ConsumerControl.press(usage);
    delay(10);
    ConsumerControl.release();
    delay(4);
  }
}
#endif

static const char *hidName(const char *action) {
#if DIAL_HID
  return gHidLive ? action : "off";
#else
  (void)action;
  return "off";
#endif
}

static void emitTurn(int dir, int detents, int repeat) {
  Line l;
  l.reset();
  l.raw("{\"t\":\"turn\",\"dir\":");
  l.i32(dir);
  l.raw(",\"pos\":");
  l.i32(gPos);
  l.raw(",\"detents\":");
  l.i32(detents);
  l.raw(",\"repeat\":");
  l.i32(repeat);
  l.raw(",\"hid\":\"");
  l.raw(hidName(dir > 0 ? "vol+" : "vol-"));
  l.raw("\"}");
  emitLine(l.d);
  rgb(dir > 0 ? 40 : 10, 16, dir > 0 ? 4 : 18);
}

static void emitBtn(const char *act, const char *hid) {
  Line l;
  l.reset();
  l.raw("{\"t\":\"btn\",\"act\":\"");
  l.raw(act);
  l.raw("\",\"hid\":\"");
  l.raw(hidName(hid));
  l.raw("\"}");
  emitLine(l.d);
  rgb(28, 14, 4);
}

static void emitBoot() {
  Line l;
  l.reset();
  l.raw("{\"t\":\"boot\",\"fw\":\"s3-dial\",\"ver\":\"");
  l.raw(kVersion);
  l.raw("\",\"hidBuild\":");
  l.raw(DIAL_HID ? "true" : "false");
  l.raw(",\"hid\":");
#if DIAL_HID
  l.raw(gHidLive ? "true" : "false");
#else
  l.raw("false");
#endif
  l.raw(",\"pos\":");
  l.i32(gPos);
  l.raw(",\"a\":");
  l.i32(kPinA);
  l.raw(",\"b\":");
  l.i32(kPinB);
  l.raw(",\"sw\":");
  l.i32(kPinSw);
  l.raw(",\"tx\":");
  l.i32(kPinHostTx);
  l.raw(",\"rx\":");
  l.i32(kPinHostRx);
  l.raw("}");
  emitLine(l.d);
}

static void handleTurn(int32_t detents) {
  if (detents == 0) return;
  int dir = detents > 0 ? 1 : -1;
  int n = detents > 0 ? detents : -detents;
  int repeat = accelRepeat(millis());
  gPos += (int32_t)dir * n;
  int taps = n * repeat;
  if (taps > 8) taps = 8;
#if DIAL_HID
  hidTap(dir > 0 ? CONSUMER_CONTROL_VOLUME_INCREMENT : CONSUMER_CONTROL_VOLUME_DECREMENT, taps);
#else
  (void)taps;
#endif
  emitTurn(dir, n, repeat);
}

static void pollButton() {
  bool raw = gpio_get_level((gpio_num_t)kPinSw) != 0;
  uint32_t now = millis();
  if (raw != gBtnLast) {
    gBtnLast = raw;
    gBtnChangeMs = now;
  }
  if ((uint32_t)(now - gBtnChangeMs) < 25) return;
  if (raw == gBtnStable) {
    if (gBtnDown && !gLongSent && (uint32_t)(now - gBtnDownMs) >= 700) {
      gLongSent = true;
      emitBtn("long", "playpause");
#if DIAL_HID
      hidTap(CONSUMER_CONTROL_PLAY_PAUSE, 1);
#endif
    }
    return;
  }
  gBtnStable = raw;
  if (!raw) {
    gBtnDown = true;
    gBtnDownMs = now;
    gLongSent = false;
  } else {
    bool wasLong = gLongSent;
    uint32_t held = now - gBtnDownMs;
    gBtnDown = false;
    gLongSent = false;
    if (!wasLong && held >= 40) {
      emitBtn("click", "mute");
#if DIAL_HID
      hidTap(CONSUMER_CONTROL_MUTE, 1);
#endif
    }
  }
}

static void upcase(char *s) {
  for (; *s; s++) {
    if (*s >= 'a' && *s <= 'z') *s = (char)(*s - 32);
  }
}

static bool printable(const char *s) {
  if (!s[0]) return false;
  for (const char *p = s; *p; p++) {
    if (*p < 32 || *p > 126) return false;
  }
  return true;
}

static void handleCmd(char *cmd) {
  if (!strcmp(cmd, "HELP")) {
    emitLine("{\"t\":\"help\",\"cmds\":[\"ID\",\"POS\",\"ZERO\",\"HID ON\",\"HID OFF\",\"HELP\"]}");
    return;
  }
  if (!strcmp(cmd, "ID")) {
    emitBoot();
    return;
  }
  if (!strcmp(cmd, "POS")) {
    Line l;
    l.reset();
    l.raw("{\"t\":\"pos\",\"pos\":");
    l.i32(gPos);
    l.raw("}");
    emitLine(l.d);
    return;
  }
  if (!strcmp(cmd, "ZERO")) {
    gPos = 0;
    portENTER_CRITICAL(&gMux);
    gQuarter = 0;
    portEXIT_CRITICAL(&gMux);
    emitLine("{\"t\":\"zero\",\"pos\":0}");
    return;
  }
  if (!strcmp(cmd, "HID ON") || !strcmp(cmd, "HID OFF")) {
    bool on = cmd[4] == 'O' && cmd[5] == 'N';
#if DIAL_HID
    gHidLive = on;
    Line l;
    l.reset();
    l.raw("{\"t\":\"hid\",\"on\":");
    l.raw(gHidLive ? "true" : "false");
    l.raw("}");
    emitLine(l.d);
#else
    (void)on;
    emitLine("{\"t\":\"hid\",\"on\":false,\"err\":\"build-has-no-usb-hid\"}");
#endif
    return;
  }
  emitLine("{\"t\":\"err\",\"msg\":\"unknown-cmd\"}");
}

static char gUsbCmd[64];
static size_t gUsbLen = 0;
static char gUartCmd[64];
static size_t gUartLen = 0;
static char gHostCmd[64];
static size_t gHostLen = 0;

static void pollStream(Stream &s, char *buf, size_t &len) {
  while (s.available()) {
    char c = (char)s.read();
    if (c == '\r') continue;
    if (c == '\n') {
      buf[len] = 0;
      if (printable(buf)) {
        upcase(buf);
        handleCmd(buf);
      }
      len = 0;
    } else if (len + 1 < 64) {
      buf[len++] = c;
    } else {
      len = 0;
    }
  }
}

static void pollCommands() {
  pollStream(Serial, gUsbCmd, gUsbLen);
#if ARDUINO_USB_CDC_ON_BOOT
  if (&Serial != &Serial0) pollStream(Serial0, gUartCmd, gUartLen);
#endif
  pollStream(HostSerial, gHostCmd, gHostLen);
}

void setup() {
  Serial.begin(115200);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial0.begin(115200);
#endif
  HostSerial.begin(115200, SERIAL_8N1, kPinHostRx, kPinHostTx);
  gpio_pullup_en((gpio_num_t)kPinHostRx);

  gPinA = (uint8_t)kPinA;
  gPinB = (uint8_t)kPinB;
  if (kSwapAB) {
    uint8_t tmp = gPinA;
    gPinA = gPinB;
    gPinB = tmp;
  }
  pinMode(kPinA, INPUT_PULLUP);
  pinMode(kPinB, INPUT_PULLUP);
  pinMode(kPinSw, INPUT_PULLUP);
  delay(2);
  gPrevAB = (uint8_t)((gpio_get_level((gpio_num_t)gPinA) << 1) | gpio_get_level((gpio_num_t)gPinB));
  attachInterrupt(digitalPinToInterrupt(kPinA), onEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(kPinB), onEncoder, CHANGE);

#if DIAL_HID
  ConsumerControl.begin();
  USB.begin();
#endif
  if (kRgbEnable) neopixelWrite((uint8_t)kPinRgb, 0, 0, 0);
  delay(200);
  emitBoot();
  if (!DIAL_HID) {
    emitLine("{\"t\":\"note\",\"msg\":\"usb-mode-is-not-otg\"}");
  }
}

void loop() {
  serviceRgb();
  pollCommands();
  pollButton();
  int32_t det = takeDetents();
  if (det != 0) handleTurn(det);
}
