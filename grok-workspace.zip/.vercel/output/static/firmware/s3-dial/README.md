# s3-dial

ESP32-S3 rotary encoder dial. Each detent is a JSON line at 115200 8N1, and a USB volume key when USB mode is OTG.

Click the encoder for mute. Hold it for play/pause. Fast spins repeat the volume key.

## Flash

Arduino IDE 2, ESP32 core 3.0 or newer. ESP32-S3 only (the C3 and the original ESP32 do not do this USB HID mode).

- Board: ESP32S3 Dev Module
- USB CDC On Boot: Enabled
- USB Mode: USB-OTG (TinyUSB)

Plug into the native USB connector for volume control. If that menu is left on Hardware CDC, the sketch still runs and prints JSON, with `"hidBuild": false`.

If the serial port disappears on the next upload, hold BOOT, tap RESET, release BOOT, and upload again.

## Wire

3.3 V only.

- CLK / A to GPIO4, DT / B to GPIO5, switch to GPIO6
- Encoder + to 3V3, GND to GND
- Optional host UART: GPIO17 TX, GPIO16 RX (same map as s3-temp)

If the direction is backwards, set `kSwapAB` to `true`. If one click sends two events, set `kStepsPerDetent` to `2`.

## Commands

`POS`, `ZERO`, `HID ON`, `HID OFF`, `ID`, `HELP`
