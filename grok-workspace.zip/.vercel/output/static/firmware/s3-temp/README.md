# s3-temp

ESP32-S3 temperature node. Newline-delimited JSON at 115200 8N1.

Default sensor is a DS18B20 on GPIO4. No Arduino libraries. Set `kSensorMode` to `0` at the top of the sketch to report the chip die temperature instead (not ambient).

## Flash

Arduino IDE 2, ESP32 core 3.0 or newer.

- Board: ESP32S3 Dev Module
- USB CDC On Boot: Enabled
- USB Mode: Hardware CDC and JTAG, or USB-OTG
- Flash size and PSRAM: match the module you have

Open this folder and upload `s3-temp.ino`. JSON is printed on the native USB port and on the UART bridge port.

## Wire

3.3 V only. Do not power the DS18B20 from 5 V.

- VDD to 3V3, GND to GND, DQ to GPIO4
- 4.7 kΩ between DQ and 3V3
- Optional host UART: GPIO17 is TX, GPIO16 is RX

## Commands

`READ`, `STREAM ON`, `STREAM OFF`, `PERIOD <ms>`, `UNIT C`, `UNIT F`, `ID`, `HELP`
