// Split S3 — temperature node
// Board: ESP32-S3. Core: Arduino-ESP32 3.0 or newer. No libraries.
//
// This is a sensor, not a thermostat. It prints newline-delimited JSON
// at 115200 8N1. The same lines go out the native USB port, the UART
// bridge port (when USB CDC on boot is enabled), and an optional host
// UART on GPIO17 (TX) / GPIO16 (RX).
//
// Wire at 3.3 V only. A DS18B20 powered from 5 V will put 5 V on DQ,
// and ESP32-S3 pins are not 5 V tolerant.
//
//   DS18B20 VDD  -> 3V3
//   DS18B20 GND  -> GND
//   DS18B20 DQ   -> GPIO4
//   4.7 kΩ       -> between GPIO4 and 3V3
//
//   GPIO17 TX    -> host RX   (optional)
//   GPIO16 RX    -> host TX   (optional)
//   GND          -> host GND
//
// Do not use GPIO19 or GPIO20 (native USB) or GPIO0 (boot strap).
// GPIO48 is a short status flash on boards with a WS2812 there.
// Set kRgbEnable to 0 if that pin is used by flash or PSRAM.
//
// kSensorMode 1 = DS18B20 on GPIO4 (real ambient / probe temperature).
// kSensorMode 0 = the chip's own die sensor. That is NOT room temperature.

static const int kSensorMode = 1;
static const int kPinDq = 4;
static const int kPinHostRx = 16;
static const int kPinHostTx = 17;
static const int kPinRgb = 48;
static const bool kRgbEnable = true;
static const char *kVersion = "1.0.0";
static const uint32_t kConvertMs = 750;
static const int kMaxSensors = 4;

#include <Arduino.h>
#include <string.h>
#include "driver/gpio.h"
#include "driver/temperature_sensor.h"
#include "esp32-hal-rgb-led.h"

static HardwareSerial HostSerial(1);

static bool gStream = true;
static char gUnit = 'C';
static uint32_t gPeriodMs = 1000;
static uint32_t gSeq = 0;
static uint32_t gLastEmitMs = 0;
static bool gWantSample = false;

enum Phase { kIdle, kWait };
static Phase gPhase = kIdle;
static uint32_t gConvStarted = 0;

static bool gDieOk = false;
static temperature_sensor_handle_t gDie = nullptr;

static bool gRgbLit = false;
static uint32_t gRgbOffAt = 0;

static uint8_t gRom[kMaxSensors][8];
static int gRomCount = 0;
static bool gHaveSkip = false;

struct Line {
  char d[512];
  size_t n;
  void reset() {
    n = 0;
    d[0] = 0;
  }
  void raw(const char *s) {
    while (*s && n + 1 < sizeof(d)) d[n++] = *s++;
    d[n] = 0;
  }
  void ch(char c) {
    if (n + 1 < sizeof(d)) {
      d[n++] = c;
      d[n] = 0;
    }
  }
  void u32(uint32_t v) {
    char tmp[16];
    snprintf(tmp, sizeof(tmp), "%lu", (unsigned long)v);
    raw(tmp);
  }
  void i32(int32_t v) {
    char tmp[16];
    snprintf(tmp, sizeof(tmp), "%ld", (long)v);
    raw(tmp);
  }
  void f2(float v) {
    char tmp[16];
    dtostrf(v, 0, 2, tmp);
    const char *p = tmp;
    while (*p == ' ') p++;
    raw(p);
  }
};

static void emitLine(const char *s) {
  Serial.println(s);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial0.println(s);
#endif
  HostSerial.println(s);
}

static void rgb(uint8_t r, uint8_t g, uint8_t b) {
  if (!kRgbEnable) return;
  neopixelWrite((uint8_t)kPinRgb, r, g, b);
  gRgbLit = (r | g | b) != 0;
  gRgbOffAt = millis() + 40;
}

static void serviceRgb() {
  if (gRgbLit && (int32_t)(millis() - gRgbOffAt) >= 0) {
    neopixelWrite((uint8_t)kPinRgb, 0, 0, 0);
    gRgbLit = false;
  }
}

static const char *sensorName() {
  return kSensorMode == 0 ? "die" : "ds18b20";
}

static void emitBoot() {
  Line l;
  l.reset();
  l.raw("{\"t\":\"boot\",\"fw\":\"s3-temp\",\"ver\":\"");
  l.raw(kVersion);
  l.raw("\",\"sensor\":\"");
  l.raw(sensorName());
  l.raw("\",\"dq\":");
  l.i32(kPinDq);
  l.raw(",\"tx\":");
  l.i32(kPinHostTx);
  l.raw(",\"rx\":");
  l.i32(kPinHostRx);
  l.raw(",\"period\":");
  l.u32(gPeriodMs);
  l.raw(",\"stream\":");
  l.raw(gStream ? "true" : "false");
  l.raw("}");
  emitLine(l.d);
}

// --- 1-Wire / DS18B20 -------------------------------------------------------

static void busBegin() {
  gpio_config_t io = {};
  io.pin_bit_mask = 1ULL << kPinDq;
  io.mode = GPIO_MODE_INPUT_OUTPUT_OD;
  io.pull_up_en = GPIO_PULLUP_ENABLE;
  io.pull_down_en = GPIO_PULLDOWN_DISABLE;
  io.intr_type = GPIO_INTR_DISABLE;
  gpio_config(&io);
  gpio_set_level((gpio_num_t)kPinDq, 1);
}

static void busLow() { gpio_set_level((gpio_num_t)kPinDq, 0); }
static void busHigh() { gpio_set_level((gpio_num_t)kPinDq, 1); }
static bool busRead() { return gpio_get_level((gpio_num_t)kPinDq) != 0; }

static bool owReset() {
  busLow();
  delayMicroseconds(480);
  busHigh();
  delayMicroseconds(70);
  bool presence = !busRead();
  delayMicroseconds(410);
  return presence;
}

static void owWriteBit(bool one) {
  if (one) {
    busLow();
    delayMicroseconds(6);
    busHigh();
    delayMicroseconds(64);
  } else {
    busLow();
    delayMicroseconds(60);
    busHigh();
    delayMicroseconds(10);
  }
}

static bool owReadBit() {
  busLow();
  delayMicroseconds(3);
  busHigh();
  delayMicroseconds(8);
  bool bit = busRead();
  delayMicroseconds(52);
  return bit;
}

static void owWrite(uint8_t v) {
  for (int i = 0; i < 8; i++) {
    owWriteBit(v & 1);
    v >>= 1;
  }
}

static uint8_t owRead() {
  uint8_t v = 0;
  for (int i = 0; i < 8; i++) {
    if (owReadBit()) v |= (uint8_t)(1 << i);
  }
  return v;
}

static uint8_t crc8(const uint8_t *data, int len) {
  uint8_t crc = 0;
  for (int i = 0; i < len; i++) {
    uint8_t in = data[i];
    for (int b = 0; b < 8; b++) {
      uint8_t mix = (crc ^ in) & 0x01;
      crc >>= 1;
      if (mix) crc ^= 0x8C;
      in >>= 1;
    }
  }
  return crc;
}

struct OwSearch {
  uint8_t rom[8];
  uint8_t lastDiscrepancy;
  bool lastDevice;
};

static bool owSearch(OwSearch &st, uint8_t out[8]) {
  if (st.lastDevice) return false;
  if (!owReset()) {
    st.lastDiscrepancy = 0;
    st.lastDevice = false;
    return false;
  }
  owWrite(0xF0);
  uint8_t lastZero = 0;
  uint8_t bitNumber = 1;
  uint8_t byteNumber = 0;
  uint8_t mask = 1;
  bool ok = false;
  do {
    uint8_t id = owReadBit();
    uint8_t cmp = owReadBit();
    if (id && cmp) break;
    uint8_t dir;
    if (id != cmp) {
      dir = id;
    } else {
      if (bitNumber < st.lastDiscrepancy) {
        dir = (st.rom[byteNumber] & mask) ? 1 : 0;
      } else {
        dir = (bitNumber == st.lastDiscrepancy) ? 1 : 0;
      }
      if (dir == 0) lastZero = bitNumber;
    }
    if (dir) st.rom[byteNumber] |= mask;
    else st.rom[byteNumber] &= (uint8_t)~mask;
    owWriteBit(dir);
    bitNumber++;
    mask <<= 1;
    if (mask == 0) {
      byteNumber++;
      mask = 1;
    }
  } while (byteNumber < 8);

  if (bitNumber >= 65 && st.rom[0] != 0) {
    st.lastDiscrepancy = lastZero;
    if (st.lastDiscrepancy == 0) st.lastDevice = true;
    memcpy(out, st.rom, 8);
    ok = crc8(out, 7) == out[7];
  } else {
    st.lastDiscrepancy = 0;
    st.lastDevice = false;
  }
  return ok;
}

static void addHex(Line &l, const uint8_t rom[8]) {
  static const char *kHex = "0123456789ABCDEF";
  for (int i = 0; i < 8; i++) {
    l.ch(kHex[rom[i] >> 4]);
    l.ch(kHex[rom[i] & 0x0F]);
  }
}

static bool readScratch(bool match, const uint8_t rom[8], float &cOut) {
  if (!owReset()) return false;
  if (match) {
    owWrite(0x55);
    for (int i = 0; i < 8; i++) owWrite(rom[i]);
  } else {
    owWrite(0xCC);
  }
  owWrite(0xBE);
  uint8_t sp[9];
  for (int i = 0; i < 9; i++) sp[i] = owRead();
  if (crc8(sp, 8) != sp[8]) return false;
  int16_t raw = (int16_t)((uint16_t)sp[0] | ((uint16_t)sp[1] << 8));
  cOut = (float)raw * 0.0625f;
  return true;
}

static void scanBus() {
  gRomCount = 0;
  gHaveSkip = false;
  OwSearch st;
  memset(&st, 0, sizeof(st));
  while (gRomCount < kMaxSensors) {
    uint8_t rom[8];
    if (!owSearch(st, rom)) break;
    memcpy(gRom[gRomCount], rom, 8);
    gRomCount++;
    if (st.lastDevice) break;
  }
  if (gRomCount == 0 && owReset()) {
    owWrite(0x33);
    uint8_t rom[8];
    for (int i = 0; i < 8; i++) rom[i] = owRead();
    if (rom[0] != 0 && crc8(rom, 7) == rom[7]) {
      memcpy(gRom[0], rom, 8);
      gRomCount = 1;
    } else {
      gHaveSkip = true;
    }
  }
}

static bool startConvert() {
  if (kSensorMode == 0) return gDieOk;
  if (!owReset()) return false;
  owWrite(0xCC);
  owWrite(0x44);
  return true;
}

static bool dieBegin() {
  temperature_sensor_config_t cfg = TEMPERATURE_SENSOR_CONFIG_DEFAULT(-10, 80);
  if (temperature_sensor_install(&cfg, &gDie) != ESP_OK) return false;
  if (temperature_sensor_enable(gDie) != ESP_OK) return false;
  return true;
}

static bool dieRead(float &cOut) {
  return temperature_sensor_get_celsius(gDie, &cOut) == ESP_OK;
}

static void emitSampleFail(const char *err) {
  gSeq++;
  Line l;
  l.reset();
  l.raw("{\"t\":\"sample\",\"seq\":");
  l.u32(gSeq);
  l.raw(",\"ms\":");
  l.u32(millis());
  l.raw(",\"ok\":false,\"sensor\":\"");
  l.raw(sensorName());
  l.raw("\",\"unit\":\"");
  l.ch(gUnit);
  l.raw("\",\"n\":0,\"err\":\"");
  l.raw(err);
  l.raw("\"}");
  emitLine(l.d);
  rgb(48, 8, 0);
}

static void emitSample(float *cels, bool *ok, int n, bool any) {
  gSeq++;
  Line l;
  l.reset();
  l.raw("{\"t\":\"sample\",\"seq\":");
  l.u32(gSeq);
  l.raw(",\"ms\":");
  l.u32(millis());
  l.raw(",\"ok\":");
  l.raw(any ? "true" : "false");
  l.raw(",\"sensor\":\"");
  l.raw(sensorName());
  l.raw("\",\"unit\":\"");
  l.ch(gUnit);
  l.raw("\",\"n\":");
  l.i32(n);
  if (any) {
    float c = 0;
    for (int i = 0; i < n; i++) {
      if (ok[i]) {
        c = cels[i];
        break;
      }
    }
    l.raw(",\"c\":");
    l.f2(c);
    l.raw(",\"f\":");
    l.f2(c * 9.0f / 5.0f + 32.0f);
  } else {
    l.raw(",\"err\":\"crc\"");
  }
  l.raw(",\"sensors\":[");
  for (int i = 0; i < n; i++) {
    if (i) l.ch(',');
    l.raw("{\"rom\":\"");
    if (kSensorMode == 0) l.raw("DIE");
    else if (gRomCount == 0) l.raw("UNKNOWN");
    else addHex(l, gRom[i]);
    l.ch('"');
    if (ok[i]) {
      l.raw(",\"c\":");
      l.f2(cels[i]);
      l.raw(",\"f\":");
      l.f2(cels[i] * 9.0f / 5.0f + 32.0f);
      l.raw(",\"ok\":true}");
    } else {
      l.raw(",\"ok\":false,\"err\":\"crc\"}");
    }
  }
  l.raw("]}");
  emitLine(l.d);
  rgb(any ? 8 : 48, any ? 28 : 8, 0);
}

static void finishSample() {
  float cels[kMaxSensors];
  bool ok[kMaxSensors];
  int n = 0;
  bool any = false;
  if (kSensorMode == 0) {
    n = 1;
    ok[0] = dieRead(cels[0]);
    any = ok[0];
    if (!any) {
      emitSampleFail("die");
      return;
    }
  } else if (gRomCount > 0) {
    n = gRomCount;
    for (int i = 0; i < n; i++) {
      ok[i] = readScratch(true, gRom[i], cels[i]);
      any = any || ok[i];
    }
  } else if (gHaveSkip) {
    n = 1;
    ok[0] = readScratch(false, nullptr, cels[0]);
    any = ok[0];
  } else {
    emitSampleFail("no-device");
    return;
  }
  emitSample(cels, ok, n, any);
}

static void queueSample() { gWantSample = true; }

static void upcase(char *s) {
  for (; *s; s++) {
    if (*s >= 'a' && *s <= 'z') *s = (char)(*s - 32);
  }
}

static bool printable(const char *s) {
  if (!s[0]) return false;
  for (const char *p = s; *p; p++) {
    if (*p < 32 || *p > 126) return false;
  }
  return true;
}

static void reply(const char *s) { emitLine(s); }

static void handleCmd(char *cmd) {
  if (!strcmp(cmd, "HELP")) {
    reply("{\"t\":\"help\",\"cmds\":[\"ID\",\"READ\",\"STREAM ON\",\"STREAM OFF\",\"PERIOD <ms>\",\"UNIT C\",\"UNIT F\",\"HELP\"]}");
    return;
  }
  if (!strcmp(cmd, "ID")) {
    emitBoot();
    return;
  }
  if (!strcmp(cmd, "READ")) {
    queueSample();
    return;
  }
  if (!strcmp(cmd, "STREAM ON")) {
    gStream = true;
    reply("{\"t\":\"stream\",\"on\":true}");
    return;
  }
  if (!strcmp(cmd, "STREAM OFF")) {
    gStream = false;
    reply("{\"t\":\"stream\",\"on\":false}");
    return;
  }
  if (!strncmp(cmd, "PERIOD ", 7)) {
    int v = atoi(cmd + 7);
    if (v < 800) v = 800;
    if (v > 60000) v = 60000;
    gPeriodMs = (uint32_t)v;
    Line l;
    l.reset();
    l.raw("{\"t\":\"period\",\"ms\":");
    l.u32(gPeriodMs);
    l.raw("}");
    reply(l.d);
    return;
  }
  if (!strcmp(cmd, "UNIT C") || !strcmp(cmd, "UNIT F")) {
    gUnit = cmd[5];
    Line l;
    l.reset();
    l.raw("{\"t\":\"unit\",\"unit\":\"");
    l.ch(gUnit);
    l.raw("\"}");
    reply(l.d);
    return;
  }
  reply("{\"t\":\"err\",\"msg\":\"unknown-cmd\"}");
}

static char gUsbCmd[64];
static size_t gUsbLen = 0;
static char gUartCmd[64];
static size_t gUartLen = 0;
static char gHostCmd[64];
static size_t gHostLen = 0;

static void pollStream(Stream &s, char *buf, size_t &len) {
  while (s.available()) {
    char c = (char)s.read();
    if (c == '\r') continue;
    if (c == '\n') {
      buf[len] = 0;
      if (printable(buf)) {
        upcase(buf);
        handleCmd(buf);
      }
      len = 0;
    } else if (len + 1 < 64) {
      buf[len++] = c;
    } else {
      len = 0;
    }
  }
}

static void pollCommands() {
  pollStream(Serial, gUsbCmd, gUsbLen);
#if ARDUINO_USB_CDC_ON_BOOT
  if (&Serial != &Serial0) pollStream(Serial0, gUartCmd, gUartLen);
#endif
  pollStream(HostSerial, gHostCmd, gHostLen);
}

void setup() {
  Serial.begin(115200);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial0.begin(115200);
#endif
  HostSerial.begin(115200, SERIAL_8N1, kPinHostRx, kPinHostTx);
  gpio_pullup_en((gpio_num_t)kPinHostRx);
  if (kSensorMode == 0) gDieOk = dieBegin();
  else busBegin();
  if (kRgbEnable) neopixelWrite((uint8_t)kPinRgb, 0, 0, 0);
  delay(200);
  emitBoot();
  if (kSensorMode == 0 && !gDieOk) emitSampleFail("die");
}

void loop() {
  serviceRgb();
  pollCommands();
  uint32_t now = millis();
  if (gPhase == kIdle) {
    uint32_t budget = kSensorMode == 0 ? 0 : kConvertMs;
    if (gStream && (uint32_t)(now - gLastEmitMs) >= (gPeriodMs > budget ? gPeriodMs - budget : 0)) {
      gWantSample = true;
    }
    if (gWantSample) {
      if (kSensorMode == 1) scanBus();
      if (!startConvert()) {
        emitSampleFail(kSensorMode == 0 ? "die" : "no-device");
        gWantSample = false;
        gLastEmitMs = now;
      } else {
        gPhase = kWait;
        gConvStarted = now;
      }
    }
  } else if ((uint32_t)(now - gConvStarted) >= (kSensorMode == 0 ? 0 : kConvertMs)) {
    finishSample();
    gPhase = kIdle;
    gWantSample = false;
    gLastEmitMs = millis();
  }
}
